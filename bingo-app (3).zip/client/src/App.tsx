import { useEffect, useState } from "react";
import socket from "./socket";

declare global {
  interface Window {
    FB: any;
    fbAsyncInit: () => void;
  }
}

const generateCard = () => {
  const card: (number | "FREE")[][] = [];
  const ranges = [
    [1, 15],
    [16, 30],
    [31, 45],
    [46, 60],
    [61, 75],
  ];
  for (let col = 0; col < 5; col++) {
    const [min, max] = ranges[col];
    const nums = new Set<number>();
    while (nums.size < 5) nums.add(Math.floor(Math.random() * (max - min + 1)) + min);
    card.push(Array.from(nums));
  }
  card[2][2] = "FREE";
  return card;
};

export default function App() {
  const [card, setCard] = useState<(number | "FREE")[][]>(generateCard());
  const [calledNumbers, setCalledNumbers] = useState<number[]>([]);
  const [leaderboard, setLeaderboard] = useState<{ [key: string]: number }>({});
  const [username, setUsername] = useState("");

  useEffect(() => {
    window.fbAsyncInit = function () {
      window.FB.init({
        appId: "YOUR_FACEBOOK_APP_ID",
        cookie: true,
        xfbml: true,
        version: "v18.0",
      });
    };
    const script = document.createElement("script");
    script.src = "https://connect.facebook.net/en_US/sdk.js";
    script.async = true;
    script.defer = true;
    document.body.appendChild(script);

    socket.on("number-called", (num: number) => {
      setCalledNumbers((prev) => [...prev, num]);
    });
    socket.on("leaderboard", (data: any) => setLeaderboard(data));

    return () => {
      socket.off("number-called");
      socket.off("leaderboard");
    };
  }, []);

  const handleFBLogin = () => {
    window.FB.login((response: any) => {
      if (response.authResponse) {
        window.FB.api("/me", (user: any) => {
          const name = user.name;
          socket.emit("join", name);
          setUsername(name);
        });
      }
    }, { scope: "public_profile,email" });
  };

  return (
    <div className="p-4 text-center">
      <h1 className="text-2xl font-bold mb-4">Bingo Online</h1>
      {!username && (
        <button onClick={handleFBLogin} className="bg-blue-500 text-white px-4 py-2 rounded">
          Login with Facebook
        </button>
      )}
      <div className="grid grid-cols-5 gap-1 w-fit mx-auto mt-4">
        {["B", "I", "N", "G", "O"].map((h, i) => (
          <div key={i} className="font-bold bg-blue-300 p-2">{h}</div>
        ))}
        {card[0].map((_, row) =>
          card.map((col, colIndex) => {
            const value = col[row];
            const isMarked = value !== "FREE" && calledNumbers.includes(value);
            return (
              <div
                key={`${row}-${colIndex}`}
                className={`p-2 border ${value === "FREE"
                    ? "bg-green-300"
                    : isMarked
                      ? "bg-yellow-300"
                      : "bg-white"
                  }`}
              >
                {value}
              </div>
            );
          })
        )}
      </div>

      <div className="mt-4">
        <h2 className="font-bold">Leaderboard</h2>
        <ul className="text-left mx-auto w-fit">
          {Object.entries(leaderboard)
            .sort((a, b) => b[1] - a[1])
            .map(([name, score]) => (
              <li key={name}>{name}: {score}</li>
            ))}
        </ul>
      </div>
    </div>
  );
}
